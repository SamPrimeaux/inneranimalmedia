# 帮助内容 - 中英双语
# Help Content - Bilingual (Chinese & English)

HELP_CONTENT = {
    "zh": {
        "title": "Meshy 插件使用说明",
        "intro": """欢迎使用 Meshy 插件！

这个插件可以帮助你检查和修复3D模型的问题，特别适合准备3D打印的模型。
下面是每个功能的详细说明：""",
        
        "sections": [
            {
                "title": "📊 分析 (Analyze)",
                "content": """这个面板用来检查你的3D模型有没有问题。

【统计功能】
• 体积 (Volume): 计算模型的体积大小，告诉你模型有多大
• 面积 (Area): 计算模型的表面积

【检查功能】
• 实体 (Solid): 检查模型是否是一个"密封"的实体
  - 非流形边: 如果有问题，说明模型有"破洞"或者边缘没有正确连接
  - 不良连续边: 检查面的方向是否一致（朝里还是朝外）

• 自相交 (Intersections): 检查模型的面有没有互相穿插
  - 3D打印时，自相交会导致打印失败

• 退化 (Degenerate): 检查有没有"坏掉"的几何体
  - 零面积的面: 面积为0的面（太小了）
  - 零长度的边: 长度为0的边（两个点重合了）

• 非平面 (Non-Planar): 检查多边形的面是否平整
  - 如果一个面不平，可能导致渲染或打印问题

• 厚度 (Thickness): 检查模型的壁厚
  - 太薄的地方打印时可能会断裂

• 锐边 (Sharp): 检查有没有特别尖锐的边缘
  - 过于尖锐的边缘可能不好打印

• 悬垂 (Overhang): 检查有没有悬空的面
  - 3D打印时，悬空太大的地方需要支撑

• 小碎片 (Small Pieces): 检测分散的小块几何体
  - 类似Houdini Labs的Delete Small工具
  - 可以找出模型中散落的小碎片、水滴等
  - 支持三种检测模式:
    * 体积: 按包围盒体积检测（单位：立方厘米）
    * 面积: 按表面积检测（单位：平方厘米）
    * 对角线: 按包围盒对角线长度检测（单位：厘米）
  - 特别适合摄影测量和流体模型的清理

• 检查全部 (Check All): 一键运行上面所有检查

【使用方法】
1. 选择你要检查的模型
2. 点击想要的检查按钮
3. 结果会显示在下方，点击结果可以选中有问题的部分
4. 进入编辑模式可以修复这些问题"""
            },
            {
                "title": "🧹 清理 (Clean Up)",
                "content": """这个面板帮你自动修复模型问题。

【功能说明】
• 使流形化 (Make Manifold): 自动修复模型
  - 删除松散的点、边、面
  - 删除内部多余的面
  - 合并重复的顶点
  - 填补破洞
  - 统一法线方向（让所有面朝外）

• 删除小碎片 (Delete Small Pieces): 自动删除分散的小块
  - 设置尺寸阈值，低于阈值的碎片会被删除
  - 支持三种模式: 体积、面积、对角线
  - 非常适合清理扫描模型或流体模型中的碎片
  - 使用前建议先用"检测小碎片"功能预览

【使用方法】
1. 选择要修复的模型
2. 点击"使流形化"按钮修复基本问题
3. 设置小碎片阈值，点击"删除小碎片"清理碎片
4. 会显示修改了多少内容"""
            },
            {
                "title": "✏️ 编辑 (Edit)",
                "content": """这个面板提供模型编辑工具。

【功能说明】
• 空心化 (Hollow): 把实心模型变成空心的
  - 偏移方向: 向内或向外偏移
  - 偏移量: 壳的厚度
  - 体素大小: 数值越小，细节越好（但处理更慢）
  - 空心副本: 创建一个空心的副本

• 对齐XY (Align XY): 让选中的面平行于地面
  - 选择模型的底部面
  - 点击按钮，模型会自动旋转

• 缩放到体积 (Scale to Volume): 把模型缩放到指定体积
• 缩放到边界 (Scale to Bounds): 把模型缩放到指定尺寸

【使用方法】
1. 选择要编辑的模型
2. 选择需要的功能
3. 调整参数后确认"""
            },
            {
                "title": "📤 导出 (Export)",
                "content": """这个面板用来导出模型文件。

【支持的格式】
• STL: 最常用的3D打印格式
• OBJ: 通用3D格式，支持材质
• PLY: 支持顶点颜色的格式

【选项说明】
• 导出路径: 文件保存的位置
• 格式: 选择导出格式
• ASCII: 用文本格式保存（文件更大但可以用文本编辑器打开）
• 场景缩放: 应用Blender的单位缩放
• UV坐标: 导出贴图坐标
• 法线: 导出法线信息
• 颜色: 导出顶点颜色
• 复制纹理: 把贴图文件一起复制到导出位置

【使用方法】
1. 选择要导出的模型
2. 设置导出路径和格式
3. 点击"导出"按钮"""
            },
            {
                "title": "💡 小贴士",
                "content": """【3D打印前的检查流程】
1. 先用"检查全部"看看有什么问题
2. 如果有问题，用"使流形化"自动修复
3. 再次检查，确保没有问题
4. 检查厚度，确保没有太薄的地方
5. 导出为STL格式

【常见问题】
Q: 检查后显示很多问题怎么办？
A: 先试试"使流形化"自动修复，大部分问题都能解决

Q: 模型太小/太大怎么办？
A: 用"缩放到边界"或"缩放到体积"调整大小

Q: 空心化后模型消失了？
A: 偏移量可能太大了，试试减小偏移量"""
            }
        ]
    },
    
    "en": {
        "title": "Meshy Plugin User Guide",
        "intro": """Welcome to Meshy Plugin!

This plugin helps you check and fix 3D model issues, especially for 3D printing preparation.
Here's a detailed guide for each feature:""",
        
        "sections": [
            {
                "title": "📊 Analyze",
                "content": """This panel checks your 3D model for problems.

【Statistics】
• Volume: Calculate the volume of your model
• Area: Calculate the surface area

【Checks】
• Solid: Check if the model is a "watertight" solid
  - Non-manifold edges: Holes or improperly connected edges
  - Bad contiguous edges: Inconsistent face directions

• Intersections: Check for self-intersecting faces
  - Self-intersections cause 3D printing failures

• Degenerate: Check for broken geometry
  - Zero-area faces: Faces that are too small
  - Zero-length edges: Overlapping vertices

• Non-Planar: Check if polygon faces are flat
  - Non-flat faces may cause rendering or printing issues

• Thickness: Check wall thickness
  - Too thin areas may break when printed

• Sharp: Check for very sharp edges
  - Extremely sharp edges are hard to print

• Overhang: Check for overhanging faces
  - Large overhangs need support when 3D printing

• Small Pieces: Detect small disconnected geometry
  - Similar to Houdini Labs Delete Small tool
  - Finds scattered fragments, droplets, etc.
  - Three detection modes:
    * Volume: By bounding box volume (cm³)
    * Area: By surface area (cm²)
    * Diagonal: By bounding box diagonal (cm)
  - Great for photogrammetry and fluid mesh cleanup

• Check All: Run all checks at once

【How to Use】
1. Select the model you want to check
2. Click the check button
3. Results appear below; click to select problem areas
4. Enter Edit Mode to fix issues"""
            },
            {
                "title": "🧹 Clean Up",
                "content": """This panel automatically fixes model issues.

【Features】
• Make Manifold: Automatically repair the model
  - Remove loose vertices, edges, and faces
  - Remove interior faces
  - Merge duplicate vertices
  - Fill holes
  - Make normals consistent (all faces pointing outward)

• Delete Small Pieces: Auto-delete scattered fragments
  - Set size threshold, pieces below threshold will be deleted
  - Three modes: Volume, Area, Diagonal
  - Great for cleaning scan/fluid models
  - Recommend using "Small Pieces" check first to preview

【How to Use】
1. Select the model to repair
2. Click "Make Manifold" to fix basic issues
3. Set threshold, click "Delete Small Pieces" to clean fragments
4. Shows what was modified"""
            },
            {
                "title": "✏️ Edit",
                "content": """This panel provides model editing tools.

【Features】
• Hollow: Make a solid model hollow
  - Offset Direction: Inward or outward
  - Offset: Shell thickness
  - Voxel Size: Smaller = more detail (but slower)
  - Hollow Duplicate: Create a hollow copy

• Align XY: Make selected faces parallel to the ground
  - Select the bottom faces
  - Click the button to auto-rotate

• Scale to Volume: Scale model to a specific volume
• Scale to Bounds: Scale model to a specific size

【How to Use】
1. Select the model to edit
2. Choose the function you need
3. Adjust parameters and confirm"""
            },
            {
                "title": "📤 Export",
                "content": """This panel exports model files.

【Supported Formats】
• STL: Most common 3D printing format
• OBJ: Universal 3D format with materials
• PLY: Format supporting vertex colors

【Options】
• Export Path: Where to save the file
• Format: Choose export format
• ASCII: Save as text format (larger but readable)
• Scene Scale: Apply Blender's unit scale
• UVs: Export texture coordinates
• Normals: Export normal information
• Colors: Export vertex colors
• Copy Textures: Copy texture files to export location

【How to Use】
1. Select models to export
2. Set export path and format
3. Click "Export" button"""
            },
            {
                "title": "💡 Tips",
                "content": """【Pre-Print Checklist】
1. Run "Check All" first
2. If issues found, use "Make Manifold" to fix
3. Check again to ensure no problems
4. Check thickness for thin areas
5. Export as STL format

【FAQ】
Q: Many issues found after checking?
A: Try "Make Manifold" first - it fixes most problems

Q: Model too small/large?
A: Use "Scale to Bounds" or "Scale to Volume"

Q: Model disappeared after hollowing?
A: Offset might be too large - try smaller values"""
            }
        ]
    }
}

