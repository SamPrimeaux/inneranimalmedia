from . import BridgePanel
from . import MeshyIcon
from . import essentials, operators, preferences, ui, report, localization
from .operators.help import MeshyHelpPreferences
import bpy
from bpy.props import PointerProperty

modules = (
    MeshyIcon,
    BridgePanel,
)

classes = essentials.get_classes((operators, preferences, ui))


def register():
    # Translations - MUST be registered BEFORE classes
    # ---------------------------
    bpy.app.translations.register(__package__, localization.DICTIONARY)
    
    for module in modules:
        module.register()
    
    # Register all new classes (includes MeshyHelpPreferences)
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # Register scene properties
    bpy.types.Scene.meshy_toolbox = PointerProperty(type=preferences.SceneProperties)
    
    # Register help preferences to WindowManager
    bpy.types.WindowManager.meshy_help_prefs = PointerProperty(type=MeshyHelpPreferences)


def unregister():
    for module in reversed(modules):
        module.unregister()
    
    # Unregister help preferences from WindowManager
    del bpy.types.WindowManager.meshy_help_prefs
    
    # Unregister scene properties
    del bpy.types.Scene.meshy_toolbox
    
    # Unregister all new classes
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    # Translations
    # ---------------------------
    bpy.app.translations.unregister(__package__)
