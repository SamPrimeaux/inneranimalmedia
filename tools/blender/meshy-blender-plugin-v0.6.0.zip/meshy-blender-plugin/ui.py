import bmesh
from bpy.app.translations import pgettext_tip as tip_
from bpy.types import Object, Panel

from . import report
from .help_content import HELP_CONTENT


def get_ui_text(key, context):
    """获取UI文本，根据用户选择的语言"""
    try:
        prefs = context.window_manager.meshy_help_prefs
        lang = prefs.help_language
    except:
        lang = "en"
    
    texts = {
        "zh": {
            "statistics": "统计",
            "checks": "检查",
            "result": "结果",
            "scale_to": "缩放到",
            "volume": "体积",
            "area": "面积",
            "bounds": "边界",
            "options": "选项",
            "general": "常规",
            "geometry": "几何",
            "materials": "材质",
            "normals": "法线",
            "colors": "颜色",
            "help_settings": "帮助与设置",
            "language": "语言",
            "help_guide": "使用说明",
            "click_help": "点击查看插件使用说明",
        },
        "en": {
            "statistics": "Statistics",
            "checks": "Checks",
            "result": "Result",
            "scale_to": "Scale To",
            "volume": "Volume",
            "area": "Area",
            "bounds": "Bounds",
            "options": "Options",
            "general": "General",
            "geometry": "Geometry",
            "materials": "Materials",
            "normals": "Normals",
            "colors": "Colors",
            "help_settings": "Help & Settings",
            "language": "Language",
            "help_guide": "User Guide",
            "click_help": "Click to view plugin guide",
        }
    }
    return texts.get(lang, texts["en"]).get(key, key)


def _is_mesh(ob: Object) -> bool:
    return ob is not None and ob.type == "MESH"


class VIEW3D_PT_meshy_analyze(Panel):
    bl_label = "Analyze"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Meshy"
    bl_options = {"DEFAULT_CLOSED"}

    _type_to_icon = {
        bmesh.types.BMVert: "VERTEXSEL",
        bmesh.types.BMEdge: "EDGESEL",
        bmesh.types.BMFace: "FACESEL",
    }

    def draw_report(self, context):
        layout = self.layout
        info = report.info()

        if info:
            is_edit = context.edit_object is not None

            row = layout.row()
            row.label(text=tip_("Result"))
            row.operator("wm.meshy_report_clear", text="", icon="X")

            box = layout.box()
            col = box.column()

            for i, (text, data) in enumerate(info):
                if is_edit and data and data[1]:
                    bm_type, _bm_array = data
                    col.operator("mesh.meshy_select_report", text=text, icon=self._type_to_icon[bm_type],).index = i
                else:
                    col.label(text=text)

    def draw(self, context):
        layout = self.layout
        layout.enabled = _is_mesh(context.object)

        props = context.scene.meshy_toolbox

        layout.label(text=tip_("Statistics"))
        row = layout.row(align=True)
        row.operator("mesh.meshy_info_volume", text=tip_("Volume"))
        row.operator("mesh.meshy_info_area", text=tip_("Area"))

        layout.label(text=tip_("Checks"))
        col = layout.column(align=True)
        col.operator("mesh.meshy_check_solid")
        col.operator("mesh.meshy_check_intersect")
        row = col.row(align=True)
        row.operator("mesh.meshy_check_degenerate")
        row.prop(props, "threshold_zero", text="")
        row = col.row(align=True)
        row.operator("mesh.meshy_check_nonplanar")
        row.prop(props, "angle_nonplanar", text="")
        row = col.row(align=True)
        row.operator("mesh.meshy_check_thick")
        row.prop(props, "thickness_min", text="")
        row = col.row(align=True)
        row.operator("mesh.meshy_check_sharp")
        row.prop(props, "angle_sharp", text="")
        row = col.row(align=True)
        row.operator("mesh.meshy_check_overhang")
        row.prop(props, "angle_overhang", text="")
        
        # Small pieces detection
        layout.separator()
        layout.label(text=tip_("Small Pieces"))
        box = layout.box()
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(props, "small_piece_mode", text="")
        row.prop(props, "small_piece_threshold", text="")
        col.operator("mesh.meshy_check_small_pieces")

        layout.operator("mesh.meshy_check_all")

        self.draw_report(context)


class VIEW3D_PT_meshy_cleanup(Panel):
    bl_label = "Clean Up"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Meshy"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        layout.enabled = _is_mesh(context.object)
        
        props = context.scene.meshy_toolbox
        
        layout.operator("mesh.meshy_clean_non_manifold")
        
        layout.separator()
        
        # Delete small pieces
        box = layout.box()
        box.label(text=tip_("Delete Small Pieces") + ":", icon="TRASH")
        
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(props, "small_piece_mode", text="")
        row.prop(props, "small_piece_threshold", text="")
        col.operator("mesh.meshy_delete_small_pieces")


class VIEW3D_PT_meshy_edit(Panel):
    bl_label = "Edit"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Meshy"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        is_mesh = _is_mesh(context.object)

        layout.operator("mesh.meshy_hollow")

        row = layout.row()
        row.enabled = is_mesh
        row.operator("object.meshy_align_xy")

        layout.label(text=tip_("Scale To"))
        row = layout.row(align=True)
        row.enabled = is_mesh
        row.operator("mesh.meshy_scale_to_volume", text=tip_("Volume"))
        row.operator("mesh.meshy_scale_to_bounds", text=tip_("Bounds"))


class VIEW3D_PT_meshy_export(Panel):
    bl_label = "Export"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Meshy"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        props = context.scene.meshy_toolbox

        layout.prop(props, "export_path", text="")
        layout.prop(props, "export_format")

        layout.operator("export_scene.meshy_export", icon="EXPORT")

        header, panel = layout.panel("options", default_closed=True)
        header.label(text=tip_("Options"))
        if panel:
            col = panel.column(heading=tip_("General"))
            sub = col.column()
            sub.active = props.export_format != "OBJ"
            sub.prop(props, "use_ascii_format")
            col.prop(props, "use_scene_scale")

            col = panel.column(heading=tip_("Geometry"))
            col.active = props.export_format != "STL"
            col.prop(props, "use_uv")
            col.prop(props, "use_normals", text=tip_("Normals"))
            col.prop(props, "use_colors", text=tip_("Colors"))

            col = panel.column(heading=tip_("Materials"))
            col.prop(props, "use_copy_textures")


class VIEW3D_PT_meshy_help(Panel):
    bl_label = "Help & Settings"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Meshy"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        
        try:
            prefs = context.window_manager.meshy_help_prefs
            lang = prefs.help_language
        except:
            lang = "en"
        
        # 语言设置
        box = layout.box()
        row = box.row()
        row.label(text="Language / 语言:", icon="WORLD")
        row.prop(prefs, "help_language", text="")
        
        layout.separator()
        
        # 帮助按钮
        if lang == "zh":
            layout.operator("wm.meshy_help", text="📖 查看使用说明", icon="HELP")
        else:
            layout.operator("wm.meshy_help", text="📖 View User Guide", icon="HELP")
        
        layout.separator()
        
        # 快速帮助信息
        box = layout.box()
        if lang == "zh":
            box.label(text="快速开始:", icon="LIGHTPROBE_VOLUME")
            col = box.column(align=True)
            col.label(text="1. 选择你的3D模型")
            col.label(text="2. 打开'分析'面板检查问题")
            col.label(text="3. 用'清理'面板修复问题")
            col.label(text="4. 用'导出'面板导出模型")
        else:
            box.label(text="Quick Start:", icon="LIGHTPROBE_VOLUME")
            col = box.column(align=True)
            col.label(text="1. Select your 3D model")
            col.label(text="2. Use 'Analyze' to check issues")
            col.label(text="3. Use 'Clean Up' to fix issues")
            col.label(text="4. Use 'Export' to export model")

