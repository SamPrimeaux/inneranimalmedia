import math

import bmesh
import bpy
from bmesh.types import BMEdge, BMFace, BMVert
from bpy.app.translations import pgettext_tip as tip_
from bpy.props import IntProperty
from bpy.types import Object, Operator

from .. import report


def _get_unit(unit_system: str, unit: str) -> tuple[float, str]:
    # Returns unit length relative to meter and unit symbol

    units = {
        "METRIC": {
            "KILOMETERS": (1000.0, "km"),
            "METERS": (1.0, "m"),
            "CENTIMETERS": (0.01, "cm"),
            "MILLIMETERS": (0.001, "mm"),
            "MICROMETERS": (0.000001, "µm"),
        },
        "IMPERIAL": {
            "MILES": (1609.344, "mi"),
            "FEET": (0.3048, "\'"),
            "INCHES": (0.0254, "\""),
            "THOU": (0.0000254, "thou"),
        },
    }

    try:
        return units[unit_system][unit]
    except KeyError:
        fallback_unit = "CENTIMETERS" if unit_system == "METRIC" else "INCHES"
        return units[unit_system][fallback_unit]


class MESH_OT_info_volume(Operator):
    bl_idname = "mesh.meshy_info_volume"
    bl_label = "Calculate Volume"
    bl_description = "Report the volume of the active mesh"

    def execute(self, context):
        from .. import lib

        scene = context.scene
        unit = scene.unit_settings
        scale = 1.0 if unit.system == "NONE" else unit.scale_length
        obj = context.active_object

        bm = lib.bmesh_copy_from_object(obj, apply_modifiers=True)
        volume = bm.calc_volume()
        bm.free()

        if unit.system == "NONE":
            volume_fmt = lib.clean_float(volume, 8)
        else:
            length, symbol = _get_unit(unit.system, unit.length_unit)

            volume_unit = volume * (scale ** 3.0) / (length ** 3.0)
            volume_str = lib.clean_float(volume_unit, 4)
            volume_fmt = f"{volume_str} {symbol}"

        report.update((tip_("Volume: {}³").format(volume_fmt), None))

        return {"FINISHED"}


class MESH_OT_info_area(Operator):
    bl_idname = "mesh.meshy_info_area"
    bl_label = "Calculate Area"
    bl_description = "Report the surface area of the active mesh"

    def execute(self, context):
        from .. import lib

        scene = context.scene
        unit = scene.unit_settings
        scale = 1.0 if unit.system == "NONE" else unit.scale_length
        obj = context.active_object

        bm = lib.bmesh_copy_from_object(obj, apply_modifiers=True)
        area = lib.bmesh_calc_area(bm)
        bm.free()

        if unit.system == "NONE":
            area_fmt = lib.clean_float(area, 8)
        else:
            length, symbol = _get_unit(unit.system, unit.length_unit)

            area_unit = area * (scale ** 2.0) / (length ** 2.0)
            area_str = lib.clean_float(area_unit, 4)
            area_fmt = f"{area_str} {symbol}"

        report.update((tip_("Area: {}²").format(area_fmt), None))

        return {"FINISHED"}


# ---------------
# Geometry Checks
#


def execute_check(self, context):
    obj = context.active_object

    info = []
    self.main_check(obj, info)
    report.update(*info)

    multiple_obj_warning(self, context)

    return {"FINISHED"}


def multiple_obj_warning(self, context) -> None:
    if len(context.selected_objects) > 1:
        self.report({"WARNING"}, "Multiple selected objects. Only the active one will be evaluated")


class MESH_OT_check_solid(Operator):
    bl_idname = "mesh.meshy_check_solid"
    bl_label = "Solid"
    bl_description = "Check for geometry is solid (has valid inside/outside) and correct normals"

    @staticmethod
    def main_check(obj: Object, info: list):
        import array
        from .. import lib

        # TODO bow-tie quads

        bm = lib.bmesh_copy_from_object(obj, transform=False, triangulate=False)

        edges_non_manifold = array.array("i", (i for i, ele in enumerate(bm.edges) if not ele.is_manifold))
        edges_non_contig = array.array("i", (i for i, ele in enumerate(bm.edges) if ele.is_manifold and (not ele.is_contiguous)))

        info.append((tip_("Non-manifold Edges: {}").format(len(edges_non_manifold)), (BMEdge, edges_non_manifold)))
        info.append((tip_("Bad Contiguous Edges: {}").format(len(edges_non_contig)), (BMEdge, edges_non_contig)))

        bm.free()

    def execute(self, context):
        return execute_check(self, context)


class MESH_OT_check_intersections(Operator):
    bl_idname = "mesh.meshy_check_intersect"
    bl_label = "Intersections"
    bl_description = "Check for self intersections"

    @staticmethod
    def main_check(obj: Object, info: list):
        from .. import lib

        faces_intersect = lib.bmesh_check_self_intersect_object(obj)
        info.append((tip_("Intersect Face: {}").format(len(faces_intersect)), (BMFace, faces_intersect)))

    def execute(self, context):
        return execute_check(self, context)


class MESH_OT_check_degenerate(Operator):
    bl_idname = "mesh.meshy_check_degenerate"
    bl_label = "Degenerate"
    bl_description = "Check for zero area faces and zero length edges"

    @staticmethod
    def main_check(obj: Object, info: list):
        import array
        from .. import lib

        # Convert from cm to Blender units (meters)
        # threshold_zero is in cm, so multiply by 0.01 to get meters
        threshold_cm = bpy.context.scene.meshy_toolbox.threshold_zero
        threshold = threshold_cm * 0.01  # cm to meters

        bm = lib.bmesh_copy_from_object(obj, transform=False, triangulate=False)

        faces_zero = array.array("i", (i for i, ele in enumerate(bm.faces) if ele.calc_area() <= threshold * threshold))
        edges_zero = array.array("i", (i for i, ele in enumerate(bm.edges) if ele.calc_length() <= threshold))

        info.append((tip_("Zero Faces: {}").format(len(faces_zero)), (BMFace, faces_zero)))
        info.append((tip_("Zero Edges: {}").format(len(edges_zero)), (BMEdge, edges_zero)))

        bm.free()

    def execute(self, context):
        return execute_check(self, context)


class MESH_OT_check_nonplanar(Operator):
    bl_idname = "mesh.meshy_check_nonplanar"
    bl_label = "Non-Planar"
    bl_description = "Check for non-flat faces"

    @staticmethod
    def main_check(obj: Object, info: list):
        import array
        from .. import lib

        angle_nonplanar = bpy.context.scene.meshy_toolbox.angle_nonplanar

        bm = lib.bmesh_copy_from_object(obj, transform=True, triangulate=False)
        bm.normal_update()

        faces_distort = array.array("i", (i for i, ele in enumerate(bm.faces) if lib.face_is_distorted(ele, angle_nonplanar)))

        info.append((tip_("Non-flat Faces: {}").format(len(faces_distort)), (BMFace, faces_distort)))

        bm.free()

    def execute(self, context):
        return execute_check(self, context)


class MESH_OT_check_thick(Operator):
    bl_idname = "mesh.meshy_check_thick"
    bl_label = "Thickness"
    bl_description = "Check for wall thickness below specified value"

    @staticmethod
    def main_check(obj: Object, info: list):
        from .. import lib

        thickness_min = bpy.context.scene.meshy_toolbox.thickness_min

        faces_error = lib.bmesh_check_thick_object(obj, thickness_min)
        info.append((tip_("Thin Faces: {}").format(len(faces_error)), (BMFace, faces_error)))

    def execute(self, context):
        return execute_check(self, context)


class MESH_OT_check_sharp(Operator):
    bl_idname = "mesh.meshy_check_sharp"
    bl_label = "Sharp"
    bl_description = "Check for edges sharper than a specified angle"

    @staticmethod
    def main_check(obj: Object, info: list):
        from .. import lib

        angle_sharp = bpy.context.scene.meshy_toolbox.angle_sharp

        bm = lib.bmesh_copy_from_object(obj, transform=True, triangulate=False)
        bm.normal_update()

        edges_sharp = [
            ele.index for ele in bm.edges
            if ele.is_manifold and ele.calc_face_angle_signed() > angle_sharp
        ]

        info.append((tip_("Sharp Edge: {}").format(len(edges_sharp)), (BMEdge, edges_sharp)))
        bm.free()

    def execute(self, context):
        return execute_check(self, context)


class MESH_OT_check_overhang(Operator):
    bl_idname = "mesh.meshy_check_overhang"
    bl_label = "Overhang"
    bl_description = "Check for faces that overhang past a specified angle"

    @staticmethod
    def main_check(obj: Object, info: list):
        from mathutils import Vector
        from .. import lib

        angle_overhang = (math.pi / 2.0) - bpy.context.scene.meshy_toolbox.angle_overhang

        if angle_overhang == math.pi:
            info.append(("Skipping Overhang", ()))
            return

        bm = lib.bmesh_copy_from_object(obj, transform=True, triangulate=False)
        bm.normal_update()

        z_down = Vector((0, 0, -1.0))
        z_down_angle = z_down.angle

        # 4.0 ignores zero area faces
        faces_overhang = [
            ele.index for ele in bm.faces
            if z_down_angle(ele.normal, 4.0) < angle_overhang
        ]

        info.append((tip_("Overhang Face: {}").format(len(faces_overhang)), (BMFace, faces_overhang)))
        bm.free()

    def execute(self, context):
        return execute_check(self, context)


class MESH_OT_check_all(Operator):
    bl_idname = "mesh.meshy_check_all"
    bl_label = "Check All"
    bl_description = "Run all checks"
    bl_options = {"INTERNAL"}

    check_cls = (
        MESH_OT_check_solid,
        MESH_OT_check_intersections,
        MESH_OT_check_degenerate,
        MESH_OT_check_nonplanar,
        MESH_OT_check_thick,
        MESH_OT_check_sharp,
        MESH_OT_check_overhang,
    )

    def execute(self, context):
        obj = context.active_object

        info = []
        for cls in self.check_cls:
            cls.main_check(obj, info)

        report.update(*info)

        multiple_obj_warning(self, context)

        return {"FINISHED"}


class MESH_OT_report_select(Operator):
    bl_idname = "mesh.meshy_select_report"
    bl_label = "Select"
    bl_description = "Select the data associated with this report"
    bl_options = {"INTERNAL"}

    index: IntProperty()

    _type_to_mode = {
        BMVert: "VERT",
        BMEdge: "EDGE",
        BMFace: "FACE",
    }

    _type_to_attr = {
        BMVert: "verts",
        BMEdge: "edges",
        BMFace: "faces",
    }

    def execute(self, context):
        obj = context.edit_object
        info = report.info()
        _text, data = info[self.index]
        bm_type, bm_array = data

        bpy.ops.mesh.reveal()
        bpy.ops.mesh.select_all(action="DESELECT")
        bpy.ops.mesh.select_mode(type=self._type_to_mode[bm_type])

        bm = bmesh.from_edit_mesh(obj.data)
        elems = getattr(bm, MESH_OT_report_select._type_to_attr[bm_type])[:]

        try:
            for i in bm_array:
                elems[i].select_set(True)
        except:
            # possible arrays are out of sync
            self.report({"ERROR"}, "Report is out of date, re-run check")

        return {"FINISHED"}


class WM_OT_report_clear(Operator):
    bl_idname = "wm.meshy_report_clear"
    bl_label = "Clear Report"
    bl_description = "Clear report"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        report.clear()
        return {"FINISHED"}


# ---------------
# Small Pieces Detection (similar to Houdini Labs Delete Small)
#

def get_loose_parts(bm):
    """
    Get all disconnected mesh islands/pieces.
    Returns a list of sets, each set contains vertex indices of one piece.
    """
    import bmesh
    
    # Ensure lookup tables are valid
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    
    visited = set()
    pieces = []
    
    for v in bm.verts:
        if v.index in visited:
            continue
        
        # BFS to find all connected vertices
        piece = set()
        queue = [v]
        
        while queue:
            current = queue.pop(0)
            if current.index in visited:
                continue
            
            visited.add(current.index)
            piece.add(current.index)
            
            # Add connected vertices through edges
            for edge in current.link_edges:
                other = edge.other_vert(current)
                if other.index not in visited:
                    queue.append(other)
        
        if piece:
            pieces.append(piece)
    
    return pieces


def calc_piece_size(bm, vert_indices, mode="VOLUME"):
    """
    Calculate the size of a mesh piece.
    mode: "VOLUME" (bounding box volume), "AREA" (surface area), "DIAGONAL" (bbox diagonal)
    """
    from mathutils import Vector
    
    if not vert_indices:
        return 0.0
    
    # Get vertices
    verts = [bm.verts[i] for i in vert_indices]
    coords = [v.co for v in verts]
    
    if not coords:
        return 0.0
    
    # Calculate bounding box
    min_co = Vector((min(c.x for c in coords), min(c.y for c in coords), min(c.z for c in coords)))
    max_co = Vector((max(c.x for c in coords), max(c.y for c in coords), max(c.z for c in coords)))
    
    size = max_co - min_co
    
    if mode == "VOLUME":
        # Bounding box volume (in cubic meters, convert to cm³)
        volume = size.x * size.y * size.z
        return volume * 1000000  # m³ to cm³
    elif mode == "AREA":
        # Calculate surface area of faces in this piece
        face_indices = set()
        for vi in vert_indices:
            v = bm.verts[vi]
            for f in v.link_faces:
                if all(fv.index in vert_indices for fv in f.verts):
                    face_indices.add(f.index)
        
        area = sum(bm.faces[fi].calc_area() for fi in face_indices)
        return area * 10000  # m² to cm²
    elif mode == "DIAGONAL":
        # Bounding box diagonal
        diagonal = size.length
        return diagonal * 100  # m to cm
    
    return 0.0


class MESH_OT_check_small_pieces(Operator):
    bl_idname = "mesh.meshy_check_small_pieces"
    bl_label = "Small Pieces"
    bl_description = "Detect small disconnected pieces (like droplets or fragments)"

    @staticmethod
    def main_check(obj: Object, info: list):
        from .. import lib
        
        props = bpy.context.scene.meshy_toolbox
        threshold = props.small_piece_threshold
        mode = props.small_piece_mode
        
        bm = lib.bmesh_copy_from_object(obj, transform=True, triangulate=False)
        
        # Get all loose parts
        pieces = get_loose_parts(bm)
        
        # Find small pieces
        small_piece_verts = []
        small_count = 0
        
        for piece in pieces:
            size = calc_piece_size(bm, piece, mode)
            if size < threshold:
                small_count += 1
                small_piece_verts.extend(piece)
        
        # Convert to array for selection
        import array
        verts_array = array.array("i", small_piece_verts)
        
        # Format size info
        mode_labels = {"VOLUME": "cm³", "AREA": "cm²", "DIAGONAL": "cm"}
        mode_label = mode_labels.get(mode, "")
        
        info.append((
            tip_("Small Pieces: {} (threshold: {:.2f} {})").format(small_count, threshold, mode_label),
            (BMVert, verts_array)
        ))
        info.append((
            tip_("Total Pieces: {}").format(len(pieces)),
            None
        ))
        
        bm.free()

    def execute(self, context):
        return execute_check(self, context)


class MESH_OT_delete_small_pieces(Operator):
    bl_idname = "mesh.meshy_delete_small_pieces"
    bl_label = "Delete Small Pieces"
    bl_description = "Delete small disconnected pieces below the size threshold"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        from .. import lib
        
        obj = context.active_object
        if not obj or obj.type != "MESH":
            self.report({"ERROR"}, "No mesh object selected")
            return {"CANCELLED"}
        
        props = context.scene.meshy_toolbox
        threshold = props.small_piece_threshold
        mode = props.small_piece_mode
        
        # Get bmesh
        bm = lib.bmesh_from_object(obj)
        
        # Get all loose parts
        pieces = get_loose_parts(bm)
        
        if len(pieces) <= 1:
            self.report({"INFO"}, "No disconnected pieces found")
            bm.free()
            return {"FINISHED"}
        
        # Find and delete small pieces
        verts_to_delete = []
        deleted_count = 0
        
        for piece in pieces:
            size = calc_piece_size(bm, piece, mode)
            if size < threshold:
                deleted_count += 1
                verts_to_delete.extend(piece)
        
        if not verts_to_delete:
            self.report({"INFO"}, "No small pieces found below threshold")
            bm.free()
            return {"FINISHED"}
        
        # Delete vertices
        bm.verts.ensure_lookup_table()
        verts_to_remove = [bm.verts[i] for i in verts_to_delete]
        bmesh.ops.delete(bm, geom=verts_to_remove, context='VERTS')
        
        # Update mesh
        lib.bmesh_to_object(obj, bm)
        bm.free()
        
        # Format size info
        mode_labels = {"VOLUME": "cm³", "AREA": "cm²", "DIAGONAL": "cm"}
        mode_label = mode_labels.get(mode, "")
        
        self.report({"INFO"}, f"Deleted {deleted_count} small pieces (threshold: {threshold:.2f} {mode_label})")
        
        return {"FINISHED"}

