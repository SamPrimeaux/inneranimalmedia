import bpy
from bpy.props import EnumProperty, StringProperty
from bpy.types import Operator

from ..help_content import HELP_CONTENT


def get_text(key, lang):
    """获取指定语言的文本"""
    return HELP_CONTENT.get(lang, HELP_CONTENT["en"]).get(key, "")


def get_section(index, lang):
    """获取指定语言的章节"""
    sections = HELP_CONTENT.get(lang, HELP_CONTENT["en"]).get("sections", [])
    if 0 <= index < len(sections):
        return sections[index]
    return None


class WM_OT_meshy_help(Operator):
    bl_idname = "wm.meshy_help"
    bl_label = "Help / 帮助"
    bl_description = "Show plugin help and user guide / 显示插件帮助和使用说明"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=500)

    def draw(self, context):
        layout = self.layout
        prefs = context.window_manager.meshy_help_prefs
        lang = prefs.help_language

        # 语言切换
        row = layout.row()
        row.label(text="Language / 语言:")
        row.prop(prefs, "help_language", text="")

        layout.separator()

        # 标题
        title = get_text("title", lang)
        layout.label(text=title, icon="HELP")

        # 简介
        intro = get_text("intro", lang)
        box = layout.box()
        for line in intro.split("\n"):
            if line.strip():
                box.label(text=line)

        layout.separator()

        # 显示详细帮助按钮
        col = layout.column(align=True)
        sections = HELP_CONTENT.get(lang, HELP_CONTENT["en"]).get("sections", [])
        for i, section in enumerate(sections):
            op = col.operator("wm.meshy_help_section", text=section["title"], icon="RIGHTARROW")
            op.section_index = i
            op.language = lang


class WM_OT_meshy_help_section(Operator):
    bl_idname = "wm.meshy_help_section"
    bl_label = "Help Section"
    bl_description = "Show detailed help for this section"
    bl_options = {"INTERNAL"}

    section_index: bpy.props.IntProperty(default=0)
    language: StringProperty(default="en")

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=550)

    def draw(self, context):
        layout = self.layout
        
        section = get_section(self.section_index, self.language)
        if not section:
            layout.label(text="Section not found")
            return

        # 标题
        layout.label(text=section["title"], icon="INFO")
        layout.separator()

        # 内容
        box = layout.box()
        col = box.column(align=True)
        
        for line in section["content"].split("\n"):
            # 处理不同类型的行
            stripped = line.strip()
            if not stripped:
                col.separator()
            elif stripped.startswith("【") or stripped.startswith("["):
                # 小标题
                col.separator()
                row = col.row()
                row.alert = True
                row.label(text=stripped)
            elif stripped.startswith("•") or stripped.startswith("-"):
                # 列表项
                col.label(text="  " + stripped)
            elif stripped.startswith("Q:") or stripped.startswith("A:"):
                # 问答
                col.label(text=stripped)
            else:
                col.label(text=stripped)

        layout.separator()
        
        # 返回按钮
        layout.operator("wm.meshy_help", text="← Back / 返回", icon="BACK")


class WM_OT_meshy_toggle_language(Operator):
    bl_idname = "wm.meshy_toggle_language"
    bl_label = "Toggle Language"
    bl_description = "Switch between Chinese and English / 切换中英文"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        prefs = context.window_manager.meshy_help_prefs
        if prefs.help_language == "zh":
            prefs.help_language = "en"
        else:
            prefs.help_language = "zh"
        return {"FINISHED"}


class MeshyHelpPreferences(bpy.types.PropertyGroup):
    help_language: EnumProperty(
        name="Language",
        description="Help language / 帮助语言",
        items=[
            ("zh", "中文", "简体中文"),
            ("en", "English", "English"),
        ],
        default="en",
    )

